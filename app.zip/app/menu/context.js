
//const remote = require('electron').remote;
//const Menu = remote.Menu;


var menu = new Menu();
menu.append(new MenuItem({ label: 'Copy',accelerator : 'Ctrl+C', role: 'copy' }));
menu.append(new MenuItem({ label: 'Cut',accelerator : 'Ctrl+X', role: 'cut' }));
menu.append(new MenuItem({ label: 'Paste',accelerator : 'Ctrl+V', role: 'paste' }));
menu.append(new MenuItem({ type: 'separator' }));
menu.append(new MenuItem({ label: 'Find',accelerator : 'Ctrl+F',click : function(){CodeMirror.commands.find(editor);} }))
menu.append(new MenuItem({ label: 'Find Next',accelerator: 'Ctrl+G',click: function(){editor.execCommand('findNext');}}))
menu.append(new MenuItem({ label: 'Find Previous',accelerator : 'Shift+Ctrl+G',click : function(){editor.execCommand('findPrev');}}));

window.addEventListener('contextmenu', function (e) {
  e.preventDefault();
  menu.popup(remote.getCurrentWindow());
}, false);
